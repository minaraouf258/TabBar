//
//  ViewController.swift
//  AnimatedTabBar
//
//  Created by mina raouf on 5/12/19.
//  Copyright © 2019 mina raouf. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

